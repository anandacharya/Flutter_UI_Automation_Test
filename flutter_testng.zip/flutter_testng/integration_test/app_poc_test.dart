import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter_testng/main.dart';
import 'robots/favorites_robot.dart';
import 'robots/home_robot.dart';

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized()
      as IntegrationTestWidgetsFlutterBinding;
  binding.framePolicy = LiveTestWidgetsFlutterBindingFramePolicy.fullyLive;

  HomeRobot homeRobot;
  FavoriteRobot favoriteRobot;

  group('e2e test', () {
    testWidgets('Scrolling test', (tester) async {
      await tester.pumpWidget(TestingApp());
      homeRobot = HomeRobot(tester);
      await homeRobot.findTitle();
      await homeRobot.scrollThePage();
    });

    testWidgets('Add items to favourites', (tester) async {
      await tester.pumpWidget(TestingApp());
      homeRobot = HomeRobot(tester);
      await homeRobot.addItemsToFavourite();
    });

    testWidgets('Remove items from favorites', (tester) async {
      await tester.pumpWidget(TestingApp());
      homeRobot = HomeRobot(tester);
      favoriteRobot = FavoriteRobot(tester);
      await homeRobot.addItemsToFavourite();
      await homeRobot.navigateToFavorite();
      await favoriteRobot.findTitle();
      await favoriteRobot.removeFavoritesItem();
      await favoriteRobot.goBack();
    });
  });
}

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class FavoriteRobot {
  const FavoriteRobot(this.tester);
  final WidgetTester tester;

  Future<void> findTitle() async {
    await tester.pumpAndSettle();
    expect(find.text('Favorites'), findsOneWidget);
  }

  Future<void> removeFavoritesItem() async {
    await tester.pumpAndSettle();
    final removeIconKeys = [
      'remove_icon_0',
      'remove_icon_1',
      'remove_icon_2',
    ];
    for (final iconKey in removeIconKeys) {
      await tester.tap(find.byKey(ValueKey(iconKey)));
      await tester.pumpAndSettle(Duration(seconds: 1));
      expect(find.text('Removed from favorites.'), findsOneWidget);
    }
  }

  Future<void> goBack() async {
    await tester.pageBack();
    await tester.pumpAndSettle();
  }
}

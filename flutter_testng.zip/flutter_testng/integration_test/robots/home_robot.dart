import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class HomeRobot {
  const HomeRobot(this.tester);
  final WidgetTester tester;

  Future<void> findTitle() async {
    await tester.pumpAndSettle();
    expect(find.text("Testing Sample"), findsOneWidget);
  }

  Future<void> scrollThePage({bool scrollUp = false}) async {
    await tester.pumpAndSettle();
    final listFinder = find.byType(ListView);
    await tester.fling(listFinder, Offset(0, -500), 10000);
    await tester.pumpAndSettle();
    await tester.fling(listFinder, Offset(0, 500), 10000);
    await tester.pumpAndSettle();
  }

  Future<void> addItemsToFavourite() async {
    await tester.pumpAndSettle();
    final iconKeys = [
      'icon_0',
      'icon_1',
      'icon_2',
    ];
    for (var icon in iconKeys) {
      await tester.tap(find.byKey(ValueKey(icon)));
      await tester.pumpAndSettle(Duration(seconds: 1));
      expect(find.text('Added to favorites.'), findsOneWidget);
    }
  }

  Future<void> navigateToFavorite() async {
    await tester.pumpAndSettle();
    await tester.tap(find.text('Favorites'));
    await tester.pumpAndSettle();
    // expect(find.text('Favorites'), findsOneWidget);
  }
}

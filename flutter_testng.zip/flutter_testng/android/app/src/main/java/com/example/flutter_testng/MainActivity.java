package com.example.flutter_testng;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
    
}
